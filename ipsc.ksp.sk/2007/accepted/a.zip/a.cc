#include <algorithm>
#include <vector>
#include <sstream>
#include <iostream>
#include <cmath>
#include <map>
#include <gmpxx.h>
using namespace std;

typedef vector<string> VS;
typedef vector<int> VI;
typedef pair<int, int> PII;
typedef long long LL;
#define all(v) (v).begin(), (v).end()
#define foreach(it,v) for(typeof((v).begin())it=(v).begin();it!=(v).end();++it)
#define REP(i, n) for (int i = 0; i < (int)(n); ++i)

vector<string> split(string s, const char *delims = " ") {
	vector<string> res;
	for (int i = 0, j; i < int(s.size()); i = j + 1) {
		j = s.find_first_of(delims, i);
		if (j == -1) j = s.size();
		if (j-i > 0) res.push_back(s.substr(i, j - i));
	}
	return res;
}


int main()
{
	int T;
	cin >> T;

	for (int cs = 1; cs <= T; cs++) {
		static char s1[10000], s2[10000], s3[10000];

		int k = scanf(" %s + %s = %s", s1, s2, s3);
		assert(k == 3);

		bool num1 = (strchr(s1, 'm') == NULL);
		bool num2 = (strchr(s2, 'm') == NULL);
		bool num3 = (strchr(s3, 'm') == NULL);

		mpz_class n1(num1 ? s1 : "0");
		mpz_class n2(num2 ? s2 : "0");
		mpz_class n3(num3 ? s3 : "0");

		if (num1 && num2) {
			cout << n1 << " + " << n2 << " = " << (n1+n2) << endl;
		} else if (num1 && num3) {
			cout << n1 << " + " << (n3-n1) << " = " << n3 << endl;
		} else if (num2 && num3) {
			cout << (n3-n2) << " + " << n2 << " = " << n3 << endl;
		} else {
			assert(false);
		}

	}
}
