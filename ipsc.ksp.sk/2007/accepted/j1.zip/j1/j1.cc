#include <algorithm>
#include <vector>
#include <sstream>
#include <iostream>
#include <cmath>
#include <map>
#include <gmpxx.h>
using namespace std;

typedef vector<string> VS;
typedef vector<int> VI;
typedef pair<int, int> PII;
typedef long long LL;
#define all(v) (v).begin(), (v).end()
#define foreach(it,v) for(typeof((v).begin())it=(v).begin();it!=(v).end();++it)
#define REP(i, n) for (int i = 0; i < (int)(n); ++i)

enum { MAXN = 256 };
int image[MAXN][MAXN];	// 0 white, 1 gray, 2 black
int width, height;

void flood(int x, int y) {
	if (y < 0 || x < 0 || y >= height || x >= width) return;

	if (image[x][y] == 0) {
		image[x][y] = 2;
		flood(x-1, y);
		flood(x+1, y);
		flood(x, y-1);
		flood(x, y+1);
	}
}

void draw_line(int x1, int y1, int x2, int y2)
{
        int x_middle = (x1+x2)/2;
        int y_middle = (y1+y2)/2;

 //       set_color(GREY);
//        put_pixel(x_middle, y_middle);
	image[x_middle][y_middle] = 1;

        if((x1!=x2) || (y1!=y2))
        {
                if(abs(x1-x2) > abs(y1-y2))
                {
                        if(x1<x2)
                        {
                                draw_line(x1, y1, x_middle, y_middle);
                                draw_line(x_middle+1, y_middle, x2, y2);
                        }
                        else // x1>x2
                        {
                                draw_line(x1, y1, x_middle+1, y_middle);
                                draw_line(x_middle, y_middle, x2, y2);
                        }
                }
                else
                {
                        if(y1<y2)
                        {
                                draw_line(x1, y1, x_middle, y_middle);
                                draw_line(x_middle, y_middle+1, x2, y2);
                        }
                        else // y1>y2
                        {
                                draw_line(x1, y1, x_middle, y_middle+1);
                                draw_line(x_middle, y_middle, x2, y2);
                        }
                }
        }
}
int main()
{
	int T;

	cin >> T;

	for (int cs = 1; cs <= T; cs++) {
		cin >> width >> height;
		memset(image, 0, sizeof(image));

		int N;
		cin >> N;
		REP(i, N) {
			int x1, y1, x2, y2;
			cin>>x1>>y1>>x2>>y2;
			draw_line(x1,y1,x2,y2);
		}

		flood(0, 0);

		int cnt[3]={0,0,0};
		REP(x,width) REP(y,height) cnt[image[x][y]]++;

		printf("%d %d %d\n", cnt[0], cnt[1], cnt[2]);


	}
}
