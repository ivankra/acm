#include <algorithm>
#include <vector>
#include <sstream>
#include <iostream>
#include <cmath>
#include <map>
#include <gmpxx.h>
using namespace std;

typedef vector<string> VS;
typedef vector<int> VI;
typedef pair<int, int> PII;
typedef long long LL;
#define all(v) (v).begin(), (v).end()
#define foreach(it,v) for(typeof((v).begin())it=(v).begin();it!=(v).end();++it)
#define REP(i, n) for (int i = 0; i < (int)(n); ++i)

vector<string> split(string s, const char *delims = " ") {
	vector<string> res;
	for (int i = 0, j; i < int(s.size()); i = j + 1) {
		j = s.find_first_of(delims, i);
		if (j == -1) j = s.size();
		if (j-i > 0) res.push_back(s.substr(i, j - i));
	}
	return res;
}

int MaxR, MaxH, MaxT;
long double f[1024][1024];

int main()
{
	int ncases;
	cin >> ncases;

	for (int cs = 1; cs <= ncases; cs++) {
		cin >> MaxR >> MaxH >> MaxT;

		for (int T = 0; T <= MaxT+1; T++)
			for (int R = 0; R <= MaxR+1; R++)
				f[0][R] = 0;

		for (int T = 1; T <= MaxT; T++) {
			for (int R = 0; R <= MaxR; R++) {
				long double sum = 0;

				for (int r = 1; r <= MaxR; r++) {
					if (r > R) {
						sum += MaxH * f[T-1][R];
						continue;
					}

					// f[T-1][r]+h <= f[T-1][R]
					// h <= f[T-1][R]-f[T-1][r];

					long long h = max(0LL, (long long)floor(f[T-1][R] - f[T-1][r]) - 2);
					if (h > MaxH) h = MaxH;

					sum += h * f[T-1][R];
					h++;

					for (int i = 0; h <= MaxH && i < 5; i++) {
						sum += max(f[T-1][r]+h, f[T-1][R]);
						h++;
					}

					if (h <= MaxH) {
						sum += (MaxH-h+1) * f[T-1][r];
						sum += MaxH * (MaxH+1.0) / 2.0;
						sum -= (h-1.0) * (h) / 2.0;
					}
				}

				f[T][R] = sum / (MaxR * (double)MaxH);
			}
		}

		double res = (double)(f[MaxT][MaxR]);
		printf("%.15f\n", res);
		fflush(stdout);
	}
}
