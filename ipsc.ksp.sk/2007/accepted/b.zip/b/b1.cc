#include <algorithm>
#include <vector>
#include <sstream>
#include <iostream>
#include <cmath>
#include <map>
#include <gmpxx.h>
using namespace std;

typedef vector<string> VS;
typedef vector<int> VI;
typedef pair<int, int> PII;
typedef long long LL;
#define all(v) (v).begin(), (v).end()
#define foreach(it,v) for(typeof((v).begin())it=(v).begin();it!=(v).end();++it)
#define REP(i, n) for (int i = 0; i < (int)(n); ++i)

vector<string> split(string s, const char *delims = " ") {
	vector<string> res;
	for (int i = 0, j; i < int(s.size()); i = j + 1) {
		j = s.find_first_of(delims, i);
		if (j == -1) j = s.size();
		if (j-i > 0) res.push_back(s.substr(i, j - i));
	}
	return res;
}

string nextSentence() {
	string res = "";

	for (;;) {
		int c = getchar();
		if (c == EOF) {
			if (res != "") assert(false /* bad EOF */);
			return "EOF";
		}
		if (c == '.') break;
		if (isspace(c)) {
			if (res.size() != 0 && res[res.size()-1] != ' ') res += ' ';
		} else {
			res += tolower(c);
		}
	}

	if (res == "new story") res = "NEW";

	return res;
}

class Story {
	bool first, valid, no_more;
	int n;

	bool match2(string s, string pattern, int &a, int &b) {
		static char buf[100];
		s += " *KIA*";
		pattern += " %s";
		strcpy(buf, "*FAILED*");
		if (sscanf(s.c_str(), pattern.c_str(), &a, &b, buf) == 3 && strcmp(buf, "*KIA*") == 0)
			return true;
		return false;
	}

	void in_out(const string &s, int in, int out) {
		if (first) {
			cout << "in_out: first sentence is " << s << endl;
			assert(false);
		}

		n -= out;
		if (n < 0) valid = false;

		n += in;

		//cout << "in="<<in<<" out="<<out<< "  n="<<n<<" [" << s << "]\n";
	}
public:
	void init() {
		first = true;
		valid = true;
		no_more = false;
		n = 0;
	}

	void next(string s) {
		if (first) {
			cout << "\nfirst: [" << s << "]\n";
		} else {
		}

		if (no_more) {
			cout << "no_more=true, while next input is: [" << s << "]\n";
		}

		int a, b;

		if (s == "the land around the bus was deserted now") {
			;
		} else if (s == "the scenery behind the windows was lovely, like pictures by some famous painter") {
			;
		} else if (s == "it was a bright summer afternoon") {
			;
		} else if (s == "dear ipsc participant, this file is intended to be processed by a machine, please don't try to get the solution manually -- in all likelyhood you will be crazy before you finish") {
			;
		} else if (match2(s, "this stop can be summarized very quickly: %d in, %d out", a, b)) {
			in_out(s, a, b);
		} else if (match2(s, "the driver was watching a cat resting on a tree, and meanwhile %d people boarded, %d came out; only then the bus started to move again", a, b)) {
			in_out(s, a, b);
		} else if (match2(s, "the bus stopped, but only %d people came in; however, %d left the bus", a, b)) {
			in_out(s, a, b);
		} else if (match2(s, "the bus stopped, but only %d people came in; however, %d left the bus", a, b)) {
			in_out(s, a, b);
		} else if (s == "once upon the time, there was an empty bus, with only the driver sitting inside") {
			n = 0;
		} else if (match2(s, "on the next stop, there were %d newcomers and %d people left the bus silently", a, b)) {
			in_out(s, a, b);
		} else if (s == "it was a bright summer afternoon") {
			;
		} else if (match2(s+" 0 ", "finally, %d people left the bus on the terminal, the driver locked the bus and, looking tired, went home %d", a, b)) {
			in_out(s, 0, a);
			valid &= (n == 0);
			no_more = true;
		} else if (match2(s, "after that, %d people got on and %d got off the bus", a, b)) {
			in_out(s, a, b);
		} else if (match2(s, "%d people got in to be voluntarily jailed in the bus, but another %d managed to escape the vehicle", a, b)) {
			in_out(s, a, b);
		} else if (s == "it seemed like no being could survive there") {
			;
		} else {
			cout << "unrecognized [" << s << "]\n";
		}

		first = false;
	}

	bool finish() {
		return valid;
	}
};

int main()
{
	Story story;
	bool eofflag = false;

	while (!eofflag) {
		story.init();

		for (;;) {
			string s = nextSentence();
			if (s == "EOF") { eofflag = true; break; }
			if (s == "NEW") break;
			story.next(s);
		}

		printf("%s\n", story.finish() ? "YES" : "NO");
	}
}
