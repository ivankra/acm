#include <algorithm>
#include <vector>
#include <sstream>
#include <iostream>
#include <cmath>
#include <map>
#include <gmpxx.h>
using namespace std;

typedef vector<string> VS;
typedef vector<int> VI;
typedef pair<int, int> PII;
typedef long long LL;
#define all(v) (v).begin(), (v).end()
#define foreach(it,v) for(typeof((v).begin())it=(v).begin();it!=(v).end();++it)
#define REP(i, n) for (int i = 0; i < (int)(n); ++i)

vector<string> split(string s, const char *delims = " ") {
	vector<string> res;
	for (int i = 0, j; i < int(s.size()); i = j + 1) {
		j = s.find_first_of(delims, i);
		if (j == -1) j = s.size();
		if (j-i > 0) res.push_back(s.substr(i, j - i));
	}
	return res;
}

enum { MAXN = 512 };

int N;
long double prob[MAXN][MAXN];
long double fw[MAXN][MAXN];
bool account[MAXN];

int main()
{
	int T;
	cin >> T;

	for (int cs = 1; cs <= T; cs++) {
		cin >> N;
		assert(N <= MAXN-5);

		for (int i = 1; i <= N; i++) {
			for (int j = 1; j <= N; j++) {
				int n;
				assert(scanf("%d", &n) == 1);
				assert(0 <= n && n <= 100);
				prob[i][j] = n / 100.0L;
			}
			prob[i][i] = 1.0L;
		}

		memset(account, 0, sizeof(account));
		account[1] = account[2] = true;

		{ int K; cin >> K; for (int i = 0; i < K; i++) {
			int x;
			cin >> x;
			account[x] = true;
		}}

		long double S;
		cin >> S;

		for (int k = 1; k <= N; k++)
			for (int i = 1; i <= N; i++)
				for (int j = 1; j <= N; j++)
					prob[i][j] >?= prob[i][k] * prob[k][j];

		for (int i = 1; i <= N; i++) {
			for (int j = 1; j <= N; j++) {
				fw[i][j] = 1.0L / 0.0L;
				if (account[i] && account[j] && prob[i][j] > 0.0) {
					fw[i][j] = S / prob[i][j];
					//printf("prob %d->%d: %.5f   [%.3f]\n", i, j, prob[i][j], S/prob[i][j]);
				}
			}
			fw[i][i] = 0.0;
		}

		for (int k = 1; k <= N; k++)
			for (int i = 1; i <= N; i++)
				for (int j = 1; j <= N; j++)
					fw[i][j] <?= fw[i][k] + fw[k][j];
		printf("%.6f\n", (double)fw[1][2]);

	}
}
